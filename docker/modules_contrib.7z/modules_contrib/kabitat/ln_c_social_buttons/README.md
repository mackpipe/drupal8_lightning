## Social Buttons Component
This module help us to add social buttons components.

Description:
============
The Lightnest social_buttons module is used to add social buttons in website.


Usage:
======
- Showing Social buttons component for each node.

Installation:
=============

Installation of this module is just like any other Drupal module.

1) Go to drupal extend and enable the module.

2) Go to admin/structure/paragraphs_type. Check Social Buttons and Social Buttons Item Paragraph type should there after install the module.

3) Go to any content type and add Social Buttons paragraph under entity reference or paragraph reference.

4) Go to that Node type page under crate a node form.

5) Fill the required detail and save the Node. Landing page should reflect the css.


Extend
-------
 - Hook_theme for extending default template of Lightnest paragraph Spacer.
