<?php

namespace Drupal\replicate\Events;

class AfterSaveEvent extends ReplicateEventBase {

}
