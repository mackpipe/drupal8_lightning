<?php

namespace Drupal\replicate\Events;

class ReplicateEntityEvent extends ReplicateEventBase {

}
